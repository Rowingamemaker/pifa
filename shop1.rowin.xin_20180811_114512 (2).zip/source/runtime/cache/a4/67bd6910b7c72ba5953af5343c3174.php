<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"gw7gF/43nFjPJIbSRG56pA==";s:6:"openid";s:28:"oZWQW0RMHY8GVnD2wt-4z-hN4mtA";}