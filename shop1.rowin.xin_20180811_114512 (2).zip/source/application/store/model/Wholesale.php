<?php

namespace app\store\model;

use app\common\model\Wholesale as WholesaleModel;
use think\Db;
use think\Request;
use app\store\model\User as UserModel;

/**
 * 批发商`模型
 * Class Wholesale
 * @package app\store\model
 */
class Wholesale extends WholesaleModel
{
    /**
     * 批发商列表
     * @return \think\Paginator
     * @throws \think\exception\DbException
     */
    public function lists()
    {
        $where = array(
            'wholesale_status' => 2,
            'is_delete' => 0
        );
        $list = self::where($where)->paginate(10, false, ['query' => Request::instance()->request()]);
        return $list;
    }

    /**
     * 审核列表
     * @return \think\Paginator
     * @throws \think\exception\DbException
     */
    public function reviewList()
    {
        $where = array(
            'wholesale_status' => array('not in', [2]),
            'is_delete' => 0
        );
        $list = self::where($where)->paginate(10, false, ['query' => Request::instance()->request()]);
        return $list;
    }

    /**
     * 添加批发商信息
     * @param array $data
     * @return bool
     */
    public function add(array $data)
    {
        // 开启事务
        Db::startTrans();
        try {
            // 添加批发商信息
            $this->allowField(true)->save($data);
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }

    /**
     * 编辑批发商信息
     * @param $data
     * @return bool
     */
    public function edit($data)
    {
        Db::startTrans();
        try {
            // 保存批发商信息
            $this->allowField(true)->save($data);
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }

    /**
     * 删除批发商
     * @return bool
     */
    public function remove()
    {
        Db::startTrans();
        try {
            //将状态改成1  删除状态
            $this->save(['is_delete' => 1, 'wholesale_status' => -1]);
            //将该用户关联的批发商改成-1  删除状态
            $userModel = new UserModel();
            $userModel->save(['wholesale_id' => -2], ['user_id' => $this['user_id']]);
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }

    public static function detail($wholesale_id)
    {
        return self::get($wholesale_id);
    }

    /**
     * 改变批发商审核状态
     * @param $wholesale_id
     * @param $wholesale_status
     * @return false|int
     */
    public function changeWholesaleStatus($wholesale_status)
    {
        $data['wholesale_status'] = $wholesale_status;
        // 开启事务
        Db::startTrans();
        try {
            $this->allowField(true)->save($data);
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
        }
        return true;
    }
}