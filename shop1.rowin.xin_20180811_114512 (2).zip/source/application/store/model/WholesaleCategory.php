<?php

namespace app\store\model;

use app\common\model\Wholesale as WholesaleModel;
use think\Db;
use think\Request;
use app\common\model\WholesaleCategory as WholesaleCategoryModel;

/**
 * Class WholesaleCategory
 * @package app\store\model
 */
class WholesaleCategory extends WholesaleCategoryModel
{
    /**
     * 批发商下的所管理的品牌分类
     * @param $wholesale_id
     * @return \think\Paginator
     * @throws \think\exception\DbException
     */
    public static function lists($wholesale_id)
    {
        $where = array(
            'wholesale_id' => $wholesale_id,
        );
        $list = self::where($where)->paginate(10, false, ['query' => Request::instance()->request()]);
        return $list;
    }


    public static function detail($wholesale_id)
    {
        return self::get($wholesale_id);
    }

    public function add($user_id, $wholesale_id, $data)
    {
        $data['user_id'] = $user_id;
        $data['wholesale_id'] = $wholesale_id;
        $data['wxapp_id'] = self::$wxapp_id;
        Db::startTrans();
        try {
            $info = self::get(['user_id' => $user_id, 'wholesale_id' => $wholesale_id,'category_id'=>$data['category_id']]);
            if (!empty($info)) {
                return false;
            }
            // 添加批发商信息
            $this->allowField(true)->save($data);
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }

    /**
     * 编辑批发商信息
     * @param $data
     * @return bool
     */
    public function edit($user_id, $wholesale_id, $data)
    {
        Db::startTrans();
        try {
            $info = self::get(['user_id' => $user_id, 'wholesale_id' => $wholesale_id,'category_id'=>$data['category_id']]);
            if (!empty($info)) {
                return false;
            }
            // 保存批发商信息
            $this->allowField(true)->save($data, ['user_id' => $user_id, 'wholesale_id' => $wholesale_id]);
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }

    /**
     * 删除批发商
     * @return bool
     */
    public function remove()
    {
        Db::startTrans();
        try {
            $this->allowField(true)->delete();
            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
        }
        return false;
    }
}