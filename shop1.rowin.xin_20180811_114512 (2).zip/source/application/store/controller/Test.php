<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/22
 * Time: 16:48
 */

namespace app\store\controller;


class Test extends Controller
{
    public function index(){
        echo phpinfo();
        die();
        echo 1532418155-1532331755;
        die();
//        echo  timeToDate(time());
    }
}