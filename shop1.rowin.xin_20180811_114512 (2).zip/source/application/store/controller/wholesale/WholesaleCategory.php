<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/26
 * Time: 19:40
 */

namespace app\store\controller\wholesale;


use app\store\controller\Controller;

class WholesaleCategory extends Controller
{
    public function index()
    {

    }
}