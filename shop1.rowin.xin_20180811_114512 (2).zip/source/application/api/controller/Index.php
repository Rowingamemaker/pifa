<?php

namespace app\api\controller;

use app\api\model\WxappPage;
use app\api\model\Goods as GoodsModel;
use app\api\model\Coupon as CouponModel;
use app\common\model\Category as CategoryModel;

/**
 * 首页控制器
 * Class Index
 * @package app\api\controller
 */
class Index extends Controller
{
    /**
     * 构造方法
     * @throws \app\common\exception\BaseException
     * @throws \think\exception\DbException
     */
    public function _initialize()
    {
        parent::_initialize();
        $this->user = $this->getUser();   // 用户信息
    }

    /**
     * 首页diy数据
     * @return array
     * @throws \think\exception\DbException
     */
    public function page()
    {
        // 页面元素
        $wxappPage = WxappPage::detail();
        $items = $wxappPage['page_data']['array']['items'];
        // 新品推荐
        $model = new GoodsModel;
        $newest = $model->getNewList();
        // 猜您喜欢
        $best = $model->getBestList();
        //优惠卷
        //筛选状态开启
        $where = array(
            'status' => 1,
            'is_delete' => 0
        );
        $couponModel = new CouponModel();
        $coupon = $couponModel->getLists($where);
        // 获取所有分类的产品
        $category = CategoryModel::getCacheTree();
        foreach ($category as $key => $secondCategory) {
            if (isset($secondCategory['child'])) {
                $arr = [];
                foreach ($secondCategory['child'] as $key1 => $value) {
                    $arr += $model->getIndexGoods($value['category_id'])->toArray();
//                    var_dump($model->getIndexGoods($value['category_id'])->toArray());
//                    die();
//                    $category[$key]['goods']=array();
//                    $category[$key]['goods']=array_merge($model->getIndexGoods($value['category_id'])->toArray(),$category[$key]['goods']);
                }
                $category[$key]['goods'] = $arr;
            }
        }
//        foreach ($category as $key1 => $first) {
//                $secondCategory=CategoryModel::getSecond($first['category_id'])->toArray();
//                foreach ($secondCategory as $key3 => $value){
//                    $category[$key1]['wxapp_id']=$model->getList(null,$value['category_id'])->toArray();
//                }
//        }
        return $this->renderSuccess(compact('items', 'newest', 'best', 'coupon', 'category'));
    }

}
