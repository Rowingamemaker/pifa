<?php

namespace app\api\model;

use app\common\model\Wholesale as WholesaleModel;
use think\Db;
use think\Exception;

/**
 * 批发商模型
 * Class Wholesale
 * @package app\api\model
 */
class Wholesale extends WholesaleModel
{
    /**
     * 加入成为批发商
     * @param $user
     * @param $data
     * @return bool
     */
    public function add($user, $data)
    {
        Db::startTrans();
        //添加批发商数据
        try {
            $this->allowField(true)->isUpdate(false)->save([
                'user_id' => $user['user_id'],//关联user表
                'wxapp_id' => self::$wxapp_id,
                'store_name' => $data['store_name'],//商户名称
                'user_name' => $data['user_name'],//商家姓名
                'address' => $data['address'],//商户地址
                'phone' => $data['phone'],//联系电话
                'wholesale_status' => 1,//待审核
                'is_delete' => 0,//正常
            ]);
            //在用户表添加批发商id
            !$user['wholesale_id'] && $user->save(['wholesale_id' => $this->wholesale_id]);
//            //添加用户的品牌权限
//            $wholesaleCategory = new WholesaleCategory();
//            $wholesaleCategory->add($user['user_id'], $this->wholesale_id, $data['category_id']);
            Db::commit();
        } catch (Exception $exception) {
            Db::rollback();
        }
        return true;
    }
}