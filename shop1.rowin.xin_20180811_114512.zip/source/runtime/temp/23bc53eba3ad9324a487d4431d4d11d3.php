<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:80:"/www/wwwroot/shop1.rowin.xin/web/../source/application/store/view/wxapp/page.php";i:1533781164;s:77:"/www/wwwroot/shop1.rowin.xin/source/application/store/view/layouts/layout.php";i:1532598380;s:76:"/www/wwwroot/shop1.rowin.xin/source/application/store/view/wxapp/tpl/diy.php";i:1532093510;s:79:"/www/wwwroot/shop1.rowin.xin/source/application/store/view/wxapp/tpl/editor.php";i:1532093510;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title><?= $setting['store']['values']['name'] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="renderer" content="webkit"/>
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="icon" type="image/png" href="assets/store/i/favicon.ico"/>
    <meta name="apple-mobile-web-app-title" content="<?= $setting['store']['values']['name'] ?>"/>
    <link rel="stylesheet" href="assets/store/css/amazeui.min.css"/>
    <link rel="stylesheet" href="assets/store/css/app.css"/>
    <link rel="stylesheet" href="//at.alicdn.com/t/font_664399_8kvutk31par79zfr.css">
    <script src="assets/store/js/jquery.min.js"></script>
    <script src="//at.alicdn.com/t/font_664399_xhxia8ezfa3ba9k9.js"></script>
    <script>
        const BASE_URL = '<?= url('/store') ?>';
    </script>
</head>

<body data-type="">
<div class="am-g tpl-g">
    <!-- 头部 -->
    <header class="tpl-header">
        <!-- 右侧内容 -->
        <div class="tpl-header-fluid">
            <!-- 侧边切换 -->
            <div class="am-fl tpl-header-button switch-button">
                <i class="iconfont">&#xe6a8;</i>
            </div>
            <!-- 刷新页面 -->
            <div class="am-fl tpl-header-button refresh-button">
                <i class="iconfont">&#xe638;</i>
            </div>
            <!-- 其它功能-->
            <div class="am-fr tpl-header-navbar">
                <ul>
                    <!-- 欢迎语 -->
                    <li class="am-text-sm tpl-header-navbar-welcome">
                        <a href="<?= url('store.user/renew') ?>">欢迎你，<span><?= $store['user']['user_name'] ?></span>
                        </a>
                    </li>
                    <!-- 退出 -->
                    <li class="am-text-sm">
                        <a href="<?= url('passport/logout') ?>">
                            <i class="iconfont">&#xe60b;</i> 退出
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <!-- 侧边导航栏 -->
    <div class="left-sidebar">
        <?php $menus = $menus ?: []; $group = $group ?: ''; $controller = $controller ?: ''; $action = $action ?: ''; $url = $controller . DS . $action;         //        echo $url; die;
        ?>
        <!-- 一级菜单 -->
        <ul class="sidebar-nav">
            <li class="sidebar-nav-heading"><?= $setting['store']['values']['name'] ?></li>
            <?php foreach ($menus as $key => $item): $first_active = $key === $group ? 'active' : '' ?>
                <li class="sidebar-nav-link">
                    <a href="<?= isset($item['url']) ? url($item['url']) : 'javascript:void(0);' ?>"
                       class="<?= $first_active ?>">
                        <?php if (isset($item['is_svg']) && $item['is_svg'] === true): ?>
                            <svg class="icon sidebar-nav-link-logo" aria-hidden="true">
                                <use xlink:href="#<?= $item['icon'] ?>"></use>
                            </svg>
                        <?php else: ?>
                            <i class="iconfont sidebar-nav-link-logo <?= $item['icon'] ?>"
                               style="<?= isset($item['color']) ? "color:{$item['color']};" : '' ?>"></i>
                        <?php endif; ?>
                        <?= $item['name'] ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        <!-- 二级菜单-->
        <?php $second = isset($menus[$group]['submenu']) ? $menus[$group]['submenu'] : []; if (!empty($second)) : ?>
            <ul class="left-sidebar-second">
                <li class="sidebar-second-title"><?= $menus[$group]['name'] ?></li>
                <li class="sidebar-second-item">
                    <?php foreach ($second as $item) : $two_active = in_array($url, $item['handle']) ? 'active' : '' ?>
                        <a href="<?= url(current($item['handle'])); ?>" class="sidebar-second-link <?= $two_active ?>">
                            <?= $item['name']; ?>
                        </a>
                    <?php endforeach; ?>
                    <!-- 三级菜单-->
                    <div style="display: none">
                        <a href="javascript:void(0);" class="sidebar-nav-sub-title">
                            <i class="iconfont icon-caret">&#xe653;</i>
                            基本功能
                        </a>
                        <ul class="sidebar-second-nav-sub">
                            <li><a href="">满额立减</a></li>
                            <li><a href="">满额包邮</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        <?php endif; ?>
    </div>

    <!-- 内容区域 start -->
    <div class="tpl-content-wrapper <?= empty($second) ? 'no-sidebar-second' : '' ?>">
        <link rel="stylesheet" href="assets/store/css/diy.css">
<div class="row-content am-cf">
    <div class="row">
        <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
            <div class="widget am-cf">
                <div class="widget-body am-cf">
                    <div class="widget-head am-cf">
                        <div class="widget-title am-fl">首页设计</div>
                    </div>
                    <!--手机diy容器-->
                    <div class="diy-phone">
                        <!-- 手机顶部标题 -->
                        <div class="phone-top"></div>
                        <!-- 小程序内容区域 -->
                        <div id="phone-main" class="phone-main"></div>
                    </div>
                    <!-- 编辑器容器 -->
                    <div id="diy-editor" class="diy-editor form-horizontal">
                        <div class="editor-arrow"></div>
                        <div class="inner"></div>
                    </div>
                    <!-- 工具栏 -->
                    <div id="diy-menu" class="diy-menu">
                        <div class="navs">
                            <div id="">
                                <div class="title">组件</div>
                                <div id="components">
                                    <nav class="special" data-type="search"> 搜索框</nav>
                                    <nav class="special" data-type="banner"> 图片轮播</nav>
                                </div>
                            </div>
                        </div>
                        <div class="action">
                            <a id="back-top" class="am-fl am-btn am-btn-xs am-btn-default" href="javascript:;">
                                <span class="am-icon-angle-double-up"></span> 返回顶部
                            </a>
                            <button id="submit" type="button" class="am-btn am-btn-xs am-btn-secondary">
                                保存页面
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--diy元素-->
<!-- diy元素: 搜索栏 -->
<script id="tpl_diy_search" type="text/template">
    <div class="drag" id="diy-{{ id }}" data-itemid="{{ id }}">
        <div class="diy-search" style="background: {{ style.background }}; padding-top:{{ style.paddingTop  }}px; ">
            <div class="inner left {{ style.searchStyle }}" style="background: {{ style.inputBackground }};">
                <div class="search-input" style="text-align: {{ style.textAlign }}; color: {{ style.inputColor }};">
                    <i class="search-icon iconfont icon-ss-search"></i>
                    <span>{{ params.placeholder }}</span>
                </div>
            </div>
        </div>
        <div class="btn-edit-del">
            <div class="btn-edit">编辑</div>
            <div class="btn-del">删除</div>
        </div>
    </div>
</script>

<!-- diy元素: banner -->
<script id="tpl_diy_banner" type="text/template">
    <div class="drag" id="diy-{{ id }}" data-itemid="{{ id }}">
        <div class="diy-banner">
            {{each data}}
                <img src="{{ $value.imgUrl }}">
            {{/each}}
            <div class="dots center {{ style.btnShape }}">
                {{each data}}
                    <span style="background: {{ style.btnColor }};"></span>
                {{/each}}
            </div>
        </div>
        <div class="btn-edit-del">
            <div class="btn-edit">编辑</div>
            <div class="btn-del">删除</div>
        </div>
    </div>
</script>


<!--编辑器: 搜索栏-->
<!--编辑器: 搜索-->
<script id="tpl_editor_search" type="text/template">
    <form class="am-form tpl-form-line-form" data-itemid="{{ id }}">
        <div class="am-form-group">
            <label class="am-u-sm-3 am-form-label am-text-xs">提示文字 </label>
            <div class="am-u-sm-9 am-u-end">
                <input class="tpl-form-input" type="text" name="searchStyle"
                       data-bind="params.placeholder" value="{{ params.placeholder }}">
            </div>
        </div>
        <div class="am-form-group">
            <label class="am-u-sm-3 am-form-label am-text-xs">搜索框样式 </label>
            <div class="am-u-sm-9 am-u-end">
                <label class="am-radio-inline">
                    <input data-bind="style.searchStyle" type="radio" name="searchStyle"
                           value="" {{ style.searchStyle=== '' ? 'checked' : '' }}> 方形
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.searchStyle" type="radio" name="searchStyle"
                           value="radius" {{ style.searchStyle=== 'radius' ? 'checked' : '' }}> 圆角
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.searchStyle" type="radio" name="searchStyle"
                           value="round" {{ style.searchStyle=== 'round' ? 'checked' : '' }}> 圆弧
                </label>
            </div>
        </div>
        <div class="am-form-group">
            <label class="am-u-sm-3 am-form-label am-text-xs">文字对齐 </label>
            <div class="am-u-sm-9 am-u-end">
                <label class="am-radio-inline">
                    <input data-bind="style.textAlign" type="radio" name="textAlign"
                           value="left" {{ style.textAlign=== 'left' ? 'checked' : '' }}>
                    居左
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.textAlign" type="radio" name="textAlign"
                           value="center" {{ style.textAlign=== 'center' ? 'checked' : '' }}>
                    居中
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.textAlign" type="radio" name="textAlign"
                           value="right" {{ style.textAlign=== 'right' ? 'checked' : '' }}>
                    居右
                </label>
            </div>
        </div>
    </form>
</script>

<!--编辑器: banner-->
<script id="tpl_editor_banner" type="text/template">
    <form class="am-form tpl-form-line-form" data-itemid="{{ id }}">
        <div class="am-form-group">
            <label class="am-u-sm-3 am-form-label am-text-xs">按钮形状 </label>
            <div class="am-u-sm-9 am-u-end">
                <label class="am-radio-inline">
                    <input data-bind="style.btnShape" type="radio" name="searchStyle"
                           value="rectangle" {{ style.btnShape=== 'rectangle' ? 'checked' : '' }}> 长方形
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.btnShape" type="radio" name="searchStyle"
                           value="square" {{ style.btnShape=== 'square' ? 'checked' : '' }}> 正方形
                </label>
                <label class="am-radio-inline">
                    <input data-bind="style.btnShape" type="radio" name="searchStyle"
                           value="round" {{ style.btnShape=== 'round' ? 'checked' : '' }}> 圆形
                </label>
            </div>
        </div>
        <div class="am-form-group">
            <label class="am-u-sm-3 am-form-label am-text-xs">按钮颜色 </label>
            <div class="am-u-sm-9 am-u-end">
                <input class="" type="color" name="btnColor"
                       data-bind="style.btnColor" value="{{ style.btnColor }}">
            </div>
        </div>
        <div class="form-items">
            {{each data}}
            <div class="item" data-key="{{ $index }}">
                <div class="container">
                    <div class="item-image"><img src="{{ $value.imgUrl }}" alt=""></div>
                    <div class="item-form am-form-file">
                        <div class="input-group">
                            <input type="text" name="imgName" data-bind="data.{{ $index }}.imgName"
                                   value="{{ $value.imgName }}" placeholder="请选择图片" readonly>
                            <span class="input-group-addon">上传图片</span>
                            <input type="hidden" name="imgUrl" data-bind="data.{{ $index }}.imgUrl"
                                   value="{{ $value.imgUrl }}">
                        </div>
                        <div class="input-group" style="margin-top:10px;">
                            <input type="text" name="linkUrl" data-bind="data.{{ $index }}.linkUrl"
                                   value="{{ $value.linkUrl }}"
                                   placeholder="请输入链接地址    例：page/index/index">
                            <!-- <span class="input-group-addon">选择链接</span> -->
                        </div>
                    </div>
                </div>
                <i class="iconfont icon-shanchu item-delete"></i>

            </div>
            {{/each}}
        </div>
        <div class="form-item-add">
            <i class="fa fa-plus"></i> 添加一个
        </div>
    </form>
</script>


<script src="assets/store/js/ddsort.js"></script>
<script src="assets/store/js/art-template.js"></script>
<script src="assets/store/js/diy.js"></script>
<script>
    $(function () {

        // 渲染diy页面
        new diyPhone(<?= $jsonData ?: '{}' ?>);


    });
</script>

    </div>
    <!-- 内容区域 end -->

</div>
<script src="assets/layer/layer.js"></script>
<script src="assets/store/js/jquery.form.min.js"></script>
<script src="assets/store/js/amazeui.min.js"></script>
<script src="assets/store/js/app.js"></script>
<script src="assets/store/js/webuploader.html5only.js"></script>
</body>

</html>
