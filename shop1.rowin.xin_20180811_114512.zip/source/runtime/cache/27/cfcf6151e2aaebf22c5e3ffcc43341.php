<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"eBsf8KhanlP8Gi64kS30yg==";s:6:"openid";s:28:"oZWQW0Xg4eSOzQEUSI_ZCOTj6mI8";}