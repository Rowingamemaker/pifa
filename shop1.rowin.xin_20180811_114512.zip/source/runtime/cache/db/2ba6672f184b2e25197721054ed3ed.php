<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"S6eJt9dK1rX9jWX6mohlyQ==";s:6:"openid";s:28:"oZWQW0XM9-ez52KQ-1sfxmS8Z_UY";}