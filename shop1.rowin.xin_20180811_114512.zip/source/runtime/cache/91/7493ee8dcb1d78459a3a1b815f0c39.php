<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"JhN8ob+RmGPFl4mPV4Equw==";s:6:"openid";s:28:"oZWQW0Q_kYhJ7GhVJMTs3uvA5Eys";}