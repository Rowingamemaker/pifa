<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"EyYa/x0/IszA4SU6jYyS2w==";s:6:"openid";s:28:"oZWQW0fvql745-svopiryWdxs8i0";}