<?php
//000000604800
 exit();?>
a:2:{s:11:"session_key";s:24:"k7RSXghLlstSueYzBvxZDQ==";s:6:"openid";s:28:"oZWQW0WrMwWtLvpKGAhdDfu0FAnM";}