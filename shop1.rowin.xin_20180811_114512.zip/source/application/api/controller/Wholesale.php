<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/24
 * Time: 16:14
 */

namespace app\api\controller;

use app\api\model\Wholesale as WholesaleModel;

class Wholesale extends Controller
{
    private $user;
    /**
     * 构造方法
     * @throws \app\common\exception\BaseException
     * @throws \think\exception\DbException
     */
    public function _initialize()
    {
        parent::_initialize();
        $this->user = $this->getUser();   // 用户信息
    }

    /**
     * 申请成为批发商
     * @return array
     * @throws \app\common\exception\BaseException
     * @throws \think\exception\DbException
     */
    public function joinWholesale()
    {
        $model = new WholesaleModel();
        //添加批发商数据
        if ($model->add($this->getUser(), $this->request->post())) {
            return $this->renderSuccess([], '申请成功');
        }
        return $this->renderError('申请失败');

    }
}