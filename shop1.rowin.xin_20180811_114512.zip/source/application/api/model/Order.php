<?php

namespace app\api\model;

use think\Db;
use app\common\model\Order as OrderModel;
use app\api\model\CouponUser as CouponUserModel;
use app\common\exception\BaseException;

/**
 * 订单模型
 * Class Order
 * @package app\api\model
 */
class Order extends OrderModel
{
    /**
     * 隐藏字段
     * @var array
     */
    protected $hidden = [
        'wxapp_id',
        'update_time'
    ];

    /**
     * 订单确认-立即购买
     * @param User $user
     * @param $goods_id
     * @param $goods_num
     * @param $goods_spec_id
     * @return array
     * @throws \think\exception\DbException
     */
    public function getBuyNow($user, $goods_id, $goods_num, $goods_spec_id, $coupon_id = 0)
    {

        // 商品信息
        /* @var Goods $goods */
        $goods = Goods::detail($goods_id);
//        var_dump($goods->spec[0]['wholesale_price']);
//        die();
        // 规格信息
        $goods['goods_spec_id'] = $goods_spec_id;
        $goods_sku = array_column($goods['spec']->toArray(), null, 'goods_spec_id')[$goods_spec_id];
        // 多规格文字内容
        $goods_sku['goods_attr'] = '';
        if ($goods['spec_type'] === 20) {
            $attrs = explode('_', $goods_sku['spec_sku_id']);
            $spec_rel = array_column($goods['spec_rel']->toArray(), null, 'spec_value_id');
            foreach ($attrs as $specValueId) {
                $goods_sku['goods_attr'] .= $spec_rel[$specValueId]['spec']['spec_name'] . ':'
                    . $spec_rel[$specValueId]['spec_value'] . '; ';
            }
        }
        $goods['goods_sku'] = $goods_sku;
        // 商品单价
        $goods['goods_price'] = $goods['goods_sku']['goods_price'];
        // 商品总价
        $goods['total_num'] = $goods_num;
        $goods['total_price'] = $totalPrice = bcmul($goods['goods_price'], $goods_num, 2);
        // 商品总重量
        $goods_total_weight = bcmul($goods['goods_sku']['goods_weight'], $goods_num, 2);
        // 当前用户收货城市id
        $cityId = $user['address_default'] ? $user['address_default']['city_id'] : null;
        //检验优惠卷是否可用 并且使用
        if ($coupon_id && Coupon::canUseCoupon($coupon_id, $goods['total_price'])) {
            //获取已领取优惠卷
            $coupon_user = CouponUser::detail(['user_id' => $user->user_id, 'coupon_id' => $coupon_id]);
            $coupon_user_id = $coupon_user['id'];//使用的优惠卷id
            $coupon_error_flag = false;//是否报错 说明优惠卷不可用
            //获取优惠卷详情
            $coupon_price = $coupon_user['sub_price'];//优惠卷减少金额
        } else {
            $coupon_error_flag = true;//是否报错 说明优惠卷不可用
            $coupon_user = array();//优惠卷详情   //不能使用的时候返回空
            $coupon_user_id = 0;//使用的优惠卷id
            $coupon_price = 0;//优惠卷减少金额
        }

        // 验证用户收货地址是否存在运费规则中
        $intraRegion = $goods['delivery']->checkAddress($cityId);
        // 计算配送费用
        $expressPrice = $intraRegion ? $goods['delivery']->calcTotalFee($goods_num, $goods_total_weight, $cityId) : 0;
        //检查是否是批发商 是的话给与减价 如果使用优惠卷的之后 金额小于0 则提示不能使用优惠券
        $wholesaleCategory = new WholesaleCategory();
        if ($wholesaleCategory->checkWholesaleCategory($user->user_id, $goods->category_id)) {
            //如果优惠券金额大于批发金额,则提示不能使用
            if ($coupon_price > $goods->spec[0]['wholesale_price']) {
                $wholesale_flag = false;
                $order_pay_price = $goods->spec[0]['wholesale_price'];
            } else {
                $wholesale_flag = true;
                $wholesale_price = $goods->spec[0]['wholesale_price'];
                $order_pay_price = bcsub($wholesale_price, $coupon_price, 2);
            }
            //付款金额=批发价
        } else {
            //没有权限 则不用批发价
            $wholesale_flag = true;
            $wholesale_price = 0;
            $order_pay_price = bcsub(bcadd($totalPrice, $expressPrice, 2), $coupon_price, 2);
        }

        return [
            'coupon_id' => $coupon_id,
            'coupon_user_id' => $coupon_user_id,//获取已优惠卷优惠卷
            'coupon_user' => $coupon_user,               //获取优惠卷
            'coupon_error_flag' => $coupon_error_flag,
            'coupon_error' => '很抱歉，该订单金额低于优惠券使用金额',
            'wholesale_price' => $wholesale_price,
            'wholesale_flag' => $wholesale_flag,
            'wholesale_error' => '很抱歉,该优惠券使用优惠金额大于批发金额',
            'goods_list' => [$goods],               // 商品详情
            'order_total_num' => $goods_num,        // 商品总数量
            'order_total_price' => $totalPrice,    // 商品总金额 (不含运费)
            'order_pay_price' => $order_pay_price,  // 实际支付金额
            'address' => $user['address_default'],  // 默认地址
            'exist_address' => !$user['address']->isEmpty(),  // 是否存在收货地址
            'express_price' => $expressPrice,    // 配送费用
            'intra_region' => $intraRegion,    // 当前用户收货城市是否存在配送规则中
            'intra_region_error' => '很抱歉，您的收货地址不在配送范围内',
        ];
    }

    /**
     * 订单确认-购物车结算
     * @param $user
     * @return array
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getCart($user)
    {
        $model = new Cart($user['user_id']);
        return $model->getList($user);
    }

    /**
     * 新增订单
     * @param $user_id
     * @param $order
     * @return bool
     * @throws \Exception
     */
    public function add($user_id, $order)
    {
        if (empty($order['address'])) {
            $this->error = '请先选择收货地址';
            return false;
        }
        if (!$order['intra_region']) {
            $this->error = $order['intra_region_error'];
            return false;
        }
        Db::startTrans();
        // 记录订单信息
        $this->save([
            'user_id' => $user_id,
            'wxapp_id' => self::$wxapp_id,
            'order_no' => $this->orderNo(),
            'total_price' => $order['order_total_price'],
            'pay_price' => $order['order_pay_price'],
            'express_price' => $order['express_price'],
            'coupon_id' => $order['coupon_id'],//优惠卷id
            'coupon_user_id' => $order['coupon_user_id'],//已领取优惠卷id
            'wholesale_price' => $order['wholesale_price'],//批发价
        ]);
        // 订单商品列表
        $goodsList = [];
        // 更新商品库存 (下单减库存)
        $deductStockData = [];
        foreach ($order['goods_list'] as $goods) {
            /* @var Goods $goods */
            $goodsList[] = [
                'user_id' => $user_id,
                'wxapp_id' => self::$wxapp_id,
                'goods_id' => $goods['goods_id'],
                'goods_name' => $goods['goods_name'],
                'image_id' => $goods['image'][0]['image_id'],
                'deduct_stock_type' => $goods['deduct_stock_type'],
                'spec_type' => $goods['spec_type'],
                'spec_sku_id' => $goods['goods_sku']['spec_sku_id'],
                'goods_spec_id' => $goods['goods_sku']['goods_spec_id'],
                'goods_attr' => $goods['goods_sku']['goods_attr'],
                'content' => $goods['content'],
                'goods_no' => $goods['goods_sku']['goods_no'],
                'goods_price' => $goods['goods_sku']['goods_price'],
                'line_price' => $goods['goods_sku']['line_price'],
                'goods_weight' => $goods['goods_sku']['goods_weight'],
                'total_num' => $goods['total_num'],
                'total_price' => $goods['total_price'],
            ];
            // 下单减库存
            $goods['deduct_stock_type'] === 10 && $deductStockData[] = [
                'goods_spec_id' => $goods['goods_sku']['goods_spec_id'],
                'stock_num' => ['dec', $goods['total_num']]
            ];
        }
        // 保存订单商品信息
        $this->goods()->saveAll($goodsList);
        // 更新商品库存
        !empty($deductStockData) && (new GoodsSpec)->isUpdate()->saveAll($deductStockData);
        //更改优惠卷使用状态
        if ($order['coupon_user_id']) {
            CouponUser::changeCouponUserStatus($order['coupon_user_id'], 2);
        }
        //
        // 记录收货地址
        $this->address()->save([
            'user_id' => $user_id,
            'wxapp_id' => self::$wxapp_id,
            'name' => $order['address']['name'],
            'phone' => $order['address']['phone'],
            'province_id' => $order['address']['province_id'],
            'city_id' => $order['address']['city_id'],
            'region_id' => $order['address']['region_id'],
            'detail' => $order['address']['detail'],
        ]);
        Db::commit();
        return true;
    }

    /**
     * 用户中心订单列表
     * @param $user_id
     * @param string $type
     * @return false|\PDOStatement|string|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function getList($user_id, $type = 'all')
    {
        // 筛选条件
        $filter = [];
        // 订单数据类型
        switch ($type) {
            case 'all':
                break;
            case 'payment';
                $filter['pay_status'] = 10;
                break;
            case 'delivery';
                $filter['pay_status'] = 20;
                $filter['delivery_status'] = 10;
                break;
            case 'received';
                $filter['pay_status'] = 20;
                $filter['delivery_status'] = 20;
                $filter['receipt_status'] = 10;
                break;
        }
        return $this->with(['goods.image'])
            ->where('user_id', '=', $user_id)
            ->where('order_status', '<>', 20)
            ->where($filter)
            ->order(['create_time' => 'desc'])
            ->select();
    }

    /**
     * 取消订单
     * @return bool|false|int
     */
    public function cancel()
    {
        if ($this['pay_status']['value'] === 20) {
            $this->error = '已付款订单不可取消';
            return false;
        }
        return $this->save(['order_status' => 20]);
    }

    /**
     * 确认收货
     * @return bool|false|int
     */
    public function receipt()
    {
        if ($this['delivery_status']['value'] === 10 || $this['receipt_status']['value'] === 20) {
            $this->error = '该订单不合法';
            return false;
        }
        return $this->save([
            'receipt_status' => 20,
            'receipt_time' => time(),
            'order_status' => 30
        ]);
    }

    /**
     * 获取订单总数
     * @param $user_id
     * @param string $type
     * @return int|string
     */
    public function getCount($user_id, $type = 'all')
    {
        // 筛选条件
        $filter = [];
        // 订单数据类型
        switch ($type) {
            case 'all':
                break;
            case 'payment';
                $filter['pay_status'] = 10;
                break;
            case 'received';
                $filter['pay_status'] = 20;
                $filter['receipt_status'] = 10;
                break;
        }
        return $this->where('user_id', '=', $user_id)
            ->where('order_status', '<>', 20)
            ->where($filter)
            ->count();
    }

    /**
     * 订单详情
     * @param $order_id
     * @param null $user_id
     * @return null|static
     * @throws BaseException
     * @throws \think\exception\DbException
     */
    public static function getUserOrderDetail($order_id, $user_id)
    {
        if (!$order = self::get([
            'order_id' => $order_id,
            'user_id' => $user_id,
            'order_status' => ['<>', 20]
        ], ['goods.image', 'address', 'coupon_user', 'coupon'])) {
            throw new BaseException(['msg' => '订单不存在']);
        }
        return $order;
    }

}
