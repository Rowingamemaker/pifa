<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/24
 * Time: 17:20
 */

namespace app\api\model;

use app\common\model\WholesaleCategory as WholesaleCategoryModel;

class WholesaleCategory extends WholesaleCategoryModel
{
    /**
     * 添加批发商的品牌权限
     * @param $wholesale_id
     * @param $category_id
     * @return false|int
     */
    public function add($user_id, $wholesale_id, $category_id)
    {
        return $this->allowField(true)->save([
            'user_id' => $user_id,
            'wholesale_id' => $wholesale_id,
            'category_id' => $category_id
        ]);
    }

    /**
     * 检查该用户是否有该品牌分类的权限 false没存在 则没权限
     * @param $user_id
     * @param $category_id
     * @return bool
     * @throws \think\exception\DbException
     */
    public function checkWholesaleCategory($user_id,$category_id){
        $info=self::get(['user_id'=>$user_id,'category_id'=>$category_id]);
        if (empty($info)){
            return false;
        }
        return true;
    }
}