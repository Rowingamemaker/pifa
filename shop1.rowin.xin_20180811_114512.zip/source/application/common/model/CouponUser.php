<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/22
 * Time: 14:31
 */

namespace app\common\model;


use think\Request;

class CouponUser extends BaseModel
{
    protected $name = "coupon_user";

}