<?php

namespace app\common\model;
/**
 * 批发商与品牌的关系模型  品牌及分类
 * Class WholesaleCategory
 * @package app\common\model
 */
class WholesaleCategory extends BaseModel
{
    protected $name = 'wholesale_category';

//    public function getCategoryIdAttr($value)
//    {
//        $category = new Category();
//        $info = $category->get($value);
//        return $info['name'];
//    }

    public function category()
    {
        return $this->hasOne('category', 'category_id', 'category_id');
    }
    public function wholesale(){
        return $this->hasMany('wholesale','wholesale_id','wholesale_id');
    }

}