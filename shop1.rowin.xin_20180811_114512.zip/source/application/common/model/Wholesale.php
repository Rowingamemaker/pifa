<?php
/**
 * Created by PhpStorm.
 * User: ROWIN
 * Date: 2018/7/24
 * Time: 17:08
 */

namespace app\common\model;


class Wholesale extends BaseModel
{
    protected $name='wholesale';


}