<?php

namespace app\task\model;

use app\common\model\GoodsSpec as GoodsSpecModel;

/**
 * 商品规格模型
 * Class GoodsSpec
 * @package app\task\model
 */
class GoodsSpec extends GoodsSpecModel
{

}
