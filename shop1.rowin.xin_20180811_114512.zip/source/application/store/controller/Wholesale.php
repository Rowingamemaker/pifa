<?php

namespace app\store\controller;

use app\store\model\Category;
use app\store\model\Delivery;
use app\store\model\Goods as GoodsModel;
use app\store\model\Wholesale as WholesaleModel;
use app\store\model\WholesaleCategory as WholesaleCategoryModel;
use app\store\model\Category as CategoryModel;

/**
 * 批发商管理
 * Class Wholesale
 * @package app\store\controller
 */
class Wholesale extends Controller
{
    const WHOLESALE_NO_PASS = -1;
    const WHOLESALE_WAIT_PASS = 1;
    const WHOLESALE__PASS = 2;

    /**
     * 批发商列表
     * @return mixed
     * @throws \think\exception\DbException
     */
    public function index()
    {
        $model = new WholesaleModel();
        $list = $model->lists();
        return $this->fetch('index', compact('list'));
    }

    public function category($user_id, $wholesale_id)
    {
        $list = WholesaleCategoryModel::lists($wholesale_id);
        foreach ($list as $key => &$value) {
            $category = CategoryModel::get($value['category_id']);
            $value['category_name'] = $category['name'];
        }
        return $this->fetch('category', compact('list', 'wholesale_id', 'user_id'));
    }

    public function categoryAdd($user_id, $wholesale_id)
    {
        if (!$this->request->isAjax()) {
            $category = Category::getCacheTree();
            return $this->fetch('categoryAdd', compact('category'));
        }
        $model = new WholesaleCategoryModel();
        if ($model->add($user_id, $wholesale_id, $this->postData('wholesale_category'))) {
            return $this->renderSuccess('添加成功', url('wholesale/category', array('user_id' => $user_id, 'wholesale_id' => $wholesale_id)));
        }
        $error = $model->getError() ?: '添加失败';
        return $this->renderError($error);
    }

    public function categoryEdit($wholesale_category_id)
    {
        $model = WholesaleCategoryModel::get($wholesale_category_id);

        if (!$this->request->isAjax()) {
            //获取所有分类品牌
            $category = Category::getCacheTree();
            return $this->fetch('categoryEdit', compact('model', 'category'));
        }
        if ($model->edit($model['user_id'], $model['wholesale_id'], $this->postData('wholesale_category'))) {
            return $this->renderSuccess('更新成功', url('wholesale/category', array('user_id' => $model['user_id'], 'wholesale_id' => $model['wholesale_id'])));
        }
        $error = $model->getError() ?: '更新失败';
        return $this->renderError($error);
    }

    public function categoryDelete($wholesale_category_id)
    {
        $model = WholesaleCategoryModel::get($wholesale_category_id);
        if (!$model->remove()) {
            return $this->renderError('删除失败');
        }
        return $this->renderSuccess('删除成功');
    }

    /**
     * 添加批发商
     * @return array|mixed
     */
    public function add()
    {
        if (!$this->request->isAjax()) {
            return $this->fetch('add');
        }

        $model = new WholesaleModel();
        if ($model->add($this->postData('wholesale'))) {
            return $this->renderSuccess('添加成功', url('wholesale/index'));
        }
        $error = $model->getError() ?: '添加失败';
        return $this->renderError($error);
    }

    /**
     * 批发商信息修改
     * @param $wholesale_id
     * @return array|mixed
     */
    public function edit($wholesale_id)
    {
        $model = WholesaleModel::detail($wholesale_id);
        if (!$this->request->isAjax()) {
            //获取所有分类品牌
            $catgory = Category::getCacheTree();
            return $this->fetch('edit', compact('model', 'catgory'));
        }
        // 更新记录
        if ($model->edit($this->postData('wholesale'))) {
            return $this->renderSuccess('更新成功', url('wholesale/index'));
        }
        $error = $model->getError() ?: '更新失败';
        return $this->renderError($error);
    }

    /**
     * 删除批发商
     * @param $wholesale_id
     * @return array
     * @throws \think\exception\DbException
     */
    public function delete($wholesale_id)
    {
        $model = WholesaleModel::get($wholesale_id);
        if (!$model->remove()) {
            return $this->renderError('删除失败');
        }
        return $this->renderSuccess('删除成功');
    }

    /**
     * 审核列表
     * @return mixed
     * @throws \think\exception\DbException
     */
    public function review()
    {
        $model = new WholesaleModel();
        $list = $model->reviewList();
        foreach ($list as $key => &$value) {
            switch ($value['wholesale_status']) {
                case self::WHOLESALE_NO_PASS:
                    $value['wholesale_status'] = '审核不通过';
                    break;
                case self::WHOLESALE_WAIT_PASS:
                    $value['wholesale_status'] = '待审核';
                    break;
                case self::WHOLESALE__PASS:
                    $value['wholesale_status'] = '审核通过';
                    break;
            }
        }
        return $this->fetch('review', compact('list'));
    }

    /**
     * 审核通过
     * @param $wholesale_id
     * @return array
     * @throws \think\exception\DbException
     */
    public function pass($wholesale_id)
    {
        // 商品详情
        $model = WholesaleModel::get($wholesale_id);
        //更新记录
        if (!$model->changeWholesaleStatus(self::WHOLESALE__PASS)) {
            return $this->renderError('修改失败');
        }
        return $this->renderSuccess('审核通过', url('wholesale/review'));
    }

    /**
     * 审核失败
     * @param $wholesale_id
     * @return array
     * @throws \think\exception\DbException
     */
    public function fail($wholesale_id)
    {
        $model = WholesaleModel::get($wholesale_id);
        if (!$model->changeWholesaleStatus(self::WHOLESALE_NO_PASS)) {
            return $this->renderError('修改失败');
        }
        return $this->renderSuccess('审核不通过', url('wholesale/review'));
    }


}
