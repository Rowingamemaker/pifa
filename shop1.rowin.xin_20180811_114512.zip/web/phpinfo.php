<?php
    echo 'a';
//    die();
    echo phpinfo();
