// pages/couponCenter/index.js
let App = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    couponList: {

    },
    inputcoupon: '',

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let _this = this;
    App._get('coupon/lists', {}, function(result) {
      if (result.code === 1) {
        _this.setData(result.data);
      } else {
        App.showError(result.msg);
      }
    });
  },
  bindinputcoupon(e) {
    var that = this
    console.log(e)
    that.setData({
      inputcoupon: e.detail.value
    })
    console.log(that.data.inputcoupon)
  },
  exchangecoupon() {
    var that = this;
    App._get('coupon/exchangeCoupon', {
      'coupon_sn': that.data.inputcoupon
    }, function(result) {
      if (result.code === 1) {
        App.showSuccess(result.msg);
      } else {
        App.showError(result.msg);
      }
    });
    // util.request(api.FindInputCup, {
    //   id: that.data.inputcoupon
    // }, 'POST').then(res => {
    //   console.log(res)
    //   if (res.errno == 11) {
    //     wx.showToast({
    //       title: '没有此优惠券！',
    //       icon: 'none',
    //       duration: 2000,
    //       mask: true,
    //       success: function(res) {},
    //       fail: function(res) {},
    //       complete: function(res) {},
    //     })
    //   }
    // })
  },

  /**
   * 领取优惠卷
   */
  get_coupon(e) {
    var that = this
    console.log(e.currentTarget.dataset.id)
    var id = e.currentTarget.dataset.id;
    var coupon_name = e.currentTarget.dataset.coupon_name;
    var couponList = this.data.couponList;
    wx.showModal({
      title: '提示',
      content: '是否领取优惠券' + coupon_name + '吗？',
      success: function(res) {
        if (res.confirm) {
          App._get('coupon/getCoupon', {
            'coupon_id': id
          }, function(result) {
            if (result.code === 1) {
              console.log(couponList);
              couponList.data.map(function(element, index, key) {
                if (element.id == id) {
                  element.get_number = element.get_number + 1;
                  element.percept = Math.floor((element.get_number / element.total_number) * 10000)/100;
                  element.coupon_status = 1;
                  return element;
                }
              })
              that.setData({
                couponList: couponList
              });
            } else {
              App.showError(result.msg);
            }
          });
        }
      },
      fail: function(res) {},
      complete: function(res) {},
    })

  },
  helptip() {
    wx.showToast({
      title: '领取后请尽快使用 ！',
      icon: 'none',
      duration: 2000,
      mask: true,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})