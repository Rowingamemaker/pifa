# 萤火小程序商城（YoShop）


#### 项目介绍
萤火小程序商城，是一款开源的电商系统，为中小企业提供最佳的新零售解决方案。采用稳定的MVC框架开发，执行效率、扩展性、稳定性值得信赖。

后端：[https://gitee.com/xany/bestshop-php](https://gitee.com/xany/bestshop-php)

#### 项目演示
- 后台演示：[http://yoshop.xany6.com/](http://yoshop.xany6.com/)
- QQ交流群：678019581

#### 项目截图
![输入图片说明](https://gitee.com/uploads/images/2018/0629/144738_39b279a7_597459.png "前端.png")

#### 二开内容

- 新增优惠卷
- 增加批发商功能  申请成为批发商以后 将可以看到批发价 并且以批发价购买
