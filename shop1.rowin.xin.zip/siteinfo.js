module.exports = {
  name: "小程序商城",
  siteroot: "https://shop1.rowin.xin/", // 必填: api地址
  // siteroot: "http://jiumangshop1.com/", // 必填: api地址
  uniacid: "10001", // 默认即可，勿填
};